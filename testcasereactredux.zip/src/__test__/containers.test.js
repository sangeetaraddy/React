import React from 'react';
import renderer from 'react-test-renderer';
import { getNews } from '../actions';
import Button from '../containers/Button';
import Loading from '../containers/Loading';
import NewsItem from '../containers/NewsItem'
// Mock react-redux connect
jest.mock('react-redux', () => ({
    connect: () => (Component) => Component, // Mock connect to simply return the component
}));

// Mock the getNews action
jest.mock('../actions', () => ({
    getNews: jest.fn(() => ({ type: 'GET_NEWS' })),
}));

describe('Button Component', () => {
    test('renders correctly', () => {
        const mockGetNews = jest.fn(); // Mock getNews function

        const component = renderer.create(
            <Button getNews={mockGetNews} /> // Pass mock function as prop
        );

        const tree = component.toJSON();
        expect(tree).toMatchSnapshot();
    });

    test('calls getNews when button is clicked', () => {
        const mockGetNews = jest.fn();

        const component = renderer.create(
            <Button getNews={mockGetNews} />
        );

        const button = component.root.findByType('button');
        button.props.onClick(); // Simulate button click

        expect(mockGetNews).toHaveBeenCalled(); // Verify function was called
    });
    test('Loading component', () => {
        const mockGetNews = jest.fn(); // Mock getNews function

        const component = renderer.create(
            <Loading /> // Pass mock function as prop
        );
        const tree = component.toJSON();
        expect(tree).toMatchSnapshot();
    });
    test('NewsItem component', () => {
        const mockGetNews = jest.fn(); // Mock getNews function

        const component = renderer.create(
            <NewsItem /> // Pass mock function as prop
        );
        const tree = component.toJSON();
        expect(tree).toMatchSnapshot();
    });
});

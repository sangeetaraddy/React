import reducer from '../reducers';

describe('Reducer', () => {
  it('reducer test for GET_NEWS',() => {
      let state ={
        news:[]
      }
      state = reducer(state, {
          action: "GET_NEWS"
      })
      expect(state).toEqual({
        news:[]
      })
  })
})

import React from 'react';
import App from '../components/App';
import {create} from 'react-test-renderer';

// Mock child components
jest.mock('../containers/Button', () => 'Button');
jest.mock('../containers/Loading', () => 'Loading');
jest.mock('../containers/NewsItem', () => 'NewsItem');

describe('App Component Snapshot', () => {
    test("App",() => {
        let tree = create(<App/>);
        expect(tree.toJSON()).toMatchSnapshot();
    })
})
